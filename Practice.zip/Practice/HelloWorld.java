class Add{
      private int a=10,b=40,c;

      public void setter(){
      c=a+b;
      }

      public int getter(){
      return c;
      }
}

public class HelloWorld{
      public static void main(String[] args){
      System.out.println("Hello world");
      Add A = new Add();
      A.setter();
      System.out.println(A.getter());
      }
}