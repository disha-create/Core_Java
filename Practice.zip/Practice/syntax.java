public class Swap{
       public static void main(String[] args){
              

       }
}