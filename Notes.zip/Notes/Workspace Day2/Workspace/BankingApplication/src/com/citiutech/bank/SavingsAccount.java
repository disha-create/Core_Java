package com.citiutech.bank;

public class SavingsAccount extends Account{

	private final static double MIN_BALANCE = 10000;
	
	public SavingsAccount() {
		// TODO Auto-generated constructor stub
		balance = MIN_BALANCE;
	}
	
	@Override
	public void withdraw(double amount) throws InsufficientFundsException {
		// TODO Auto-generated method stub
		if(balance - amount < MIN_BALANCE)
			throw new InsufficientFundsException();
		
		balance -= amount;
	}

	@Override
	public void deposit(double amount) {
		// TODO Auto-generated method stub
		balance += amount;
	}

}
