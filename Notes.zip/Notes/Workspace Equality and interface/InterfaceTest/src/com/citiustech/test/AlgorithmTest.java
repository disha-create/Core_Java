package com.citiustech.test;

import com.citiustech.Algorithm;


public class AlgorithmTest {

	public static boolean isLess(int value) {
		return value < 9;
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] numbers = {1, 2, 3, 4, 5, 6, 7, 8, 9};
		System.out.print("Deepak All numbers: ");
		Algorithm.printAll(numbers);
		System.out.print("Yash Odd numbers: ");
		//Algorithm.printOdd(numbers);
		Algorithm.printIf(numbers, new Yash());
		
		System.out.print("Keval even numbers: ");
		Algorithm.printIf(numbers, new Keval());
		
		System.out.print("Sanket numbers > 5 : ");
		Algorithm.printIf(numbers, new Sanket());
		
		System.out.printf("Arpan numbers less than 9 : ");
		Algorithm.printIf(numbers, AlgorithmTest::isLess); //Method reference
		//Algorithm.printIf(numbers, new SomeClass());
		
		System.out.printf("Vaishnav numbers less than 4 : ");
		Algorithm.printIf(numbers, n -> n < 4); //Lambda expression
								/*someFunction(int n){
									return n < 4;
								}*/
	}

}

/*
 * Algorithm.printIf(numbers, AlgorithmTest::isLess); //Method reference
 * class SomeClass implemenets Filter{
 * 	@Override 
 *  public boolean allowed(int value){
 *  	return AlgorithmTest::isLess();
 *  }
 * }
 */


