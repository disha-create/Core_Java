package com.citiustech;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
public class UpdateTest {

	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		int pno = 301;//Integer.parseInt(args[0]);
		int stock = 7; //Integer.parseInt(args[1]); //"20" -> 20  
		/*
		 * try(Connection con =
		 * DriverManager.getConnection("jdbc:mysql://localhost/sales", "root", "root")){
		 * try(Statement stmt = con.createStatement()){ int n =
		 * stmt.executeUpdate("update products set stock=stock+5 where pno=301");
		 * System.out.printf("%d rows were updated", n); } }
		 */
		try(Connection con = DriverManager.getConnection("jdbc:mysql://localhost/sales", "root", "root")){
			try(PreparedStatement pstmt = con.prepareStatement("update products set stock = stock + ? where pno = ?")){
				pstmt.setInt(1, stock);
				pstmt.setInt(2, pno);
				int n = pstmt.executeUpdate();
				System.out.printf("%d rows were updated", n);
			}
		}
	}
}




