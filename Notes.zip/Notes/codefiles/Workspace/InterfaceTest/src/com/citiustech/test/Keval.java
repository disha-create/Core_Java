package com.citiustech.test;

import com.citiustech.Filter;

public class Keval implements Filter{

	public boolean allowed(int value) {
		return value % 2 == 0;
	}
}
