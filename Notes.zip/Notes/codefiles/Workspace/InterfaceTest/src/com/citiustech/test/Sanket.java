package com.citiustech.test;

import com.citiustech.Filter;

public class Sanket implements Filter {

	@Override
	public boolean allowed(int value) {
		// TODO Auto-generated method stub
		return value > 5;
	}

}
