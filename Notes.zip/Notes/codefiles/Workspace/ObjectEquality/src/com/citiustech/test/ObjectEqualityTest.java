package com.citiustech.test;

import com.citiustech.Interval;

public class ObjectEqualityTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Interval a = new Interval(5, 75);
		a.print();
		Interval b = new Interval(9, 80);
		b.print();
		Interval c = a;
		System.out.println(b); //b.toString()
		System.out.println(b.toString());
		System.out.printf("a identical to b : %s%n", a == b);
		System.out.printf("%d\t%d%n", a.hashCode(), b.hashCode());
		System.out.printf("a identical to b : %s%n", a.hashCode() == b.hashCode());
		System.out.printf("a is equal to b : %s%n", a.equals(b));
		System.out.printf("a is equal to c : %s%n", a.equals(c));
		System.out.printf("a identical to c : %s%n", a.hashCode() == c.hashCode());
		
	}

}
