package test;

import payroll.Employee;
import payroll.SalesPerson;

public class ArrayTest {
	
	private static double totalIncome(Employee[] dept) {
		double total = 0;
		
		for (Employee emp : dept) {
			//System.out.println("Call from " + emp.getClass());
			total += emp.getNetIncome();
		}
		
		return total;
	}
	
	private static double totalSales(Employee[] dept) {
		double total = 0;
		
		for (Employee emp : dept) {
			if(emp instanceof SalesPerson) {
				SalesPerson sp = (SalesPerson) emp;
				total += sp.getSales();
			}
		}
		
		return total;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Employee[] employees = new Employee[4];
		employees[0] = new Employee(180, 100);
		employees[1] = new SalesPerson(180, 100, 50000);
		employees[2] = new SalesPerson(200, 100, 150000);
		employees[3] = new Employee(200, 100);
		
		for (Employee employee : employees) {
			System.out.println(employee.getNetIncome());
		}
		System.out.printf("Total income = %.2f%n", totalIncome(employees));
		System.out.printf("Total sales = %.2f%n", totalSales(employees));
	}

}







