package com.citiutech.bank;

//Un-Checked Exception
public class IllegalTransferException extends RuntimeException {
}
