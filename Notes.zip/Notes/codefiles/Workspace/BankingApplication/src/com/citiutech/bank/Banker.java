package com.citiutech.bank;

public class Banker {

	public static Account openSavingsAccount() {
		Account acc = new SavingsAccount();
		acc.id = (int) System.currentTimeMillis() % 100000;
		return acc;
	}
	
	public static Account openCurrentAccount() {
		Account acc = new CurrentAccount();
		acc.id = (int) System.currentTimeMillis() % 100000;
		return acc;
	}
}


