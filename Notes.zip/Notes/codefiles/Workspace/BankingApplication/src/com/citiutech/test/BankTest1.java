package com.citiutech.test;

import com.citiutech.bank.Account;
import com.citiutech.bank.CurrentAccount;
import com.citiutech.bank.InsufficientFundsException;
import com.citiutech.bank.SavingsAccount;

public class BankTest1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Account sacc = new SavingsAccount();
		sacc.deposit(7000);
		Account cacc = new CurrentAccount();
		cacc.deposit(9000);
		System.out.printf("Savings Account Balance = %.2f%n", sacc.getBalance());
		System.out.printf("Current Account Balance = %.2f%n", cacc.getBalance());
		try {
			sacc.transfer(15000, cacc);
		}catch(InsufficientFundsException e) {
			System.out.println("ERROR: Transfer failed due to lack of funds!");
		}
		System.out.println("After transfer");
		System.out.printf("Savings Account Balance = %.2f%n", sacc.getBalance());
		System.out.printf("Current Account Balance = %.2f%n", cacc.getBalance());
	}
}




