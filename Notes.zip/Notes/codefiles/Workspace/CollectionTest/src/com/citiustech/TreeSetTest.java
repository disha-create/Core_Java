package com.citiustech;

import java.util.Comparator;
import java.util.Set;
import java.util.TreeSet;

public class TreeSetTest {
	
	//Nested class
	static class IntervalComparator implements Comparator<Interval>{

		@Override
		public int compare(Interval o1, Interval o2) {
			// TODO Auto-generated method stub
			return o1.getSeconds() - o2.getSeconds();
		}
		
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//Set<Interval> store = new TreeSet<Interval>();
		//Set<Interval> store = new TreeSet<Interval>(new IntervalComparator());
		Set<Interval> store = new TreeSet<Interval>((a, b) -> a.getSeconds() - b.getSeconds());

		store.add(new Interval(4, 7));
		store.add(new Interval(6, 2));
		store.add(new Interval(8, 5));
		store.add(new Interval(2, 4));
		store.add(new Interval(9, 1));
		
		for (Interval interval : store) {
			System.out.println(interval);
		}

	}

}
