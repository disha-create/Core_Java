package com.citiustech;

public class AutoBoxTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int x = 7;
		System.out.println(x);
		Object obj = x; // Object obj = new Integer(x);
		System.out.println(obj);
		int y = (int) obj;
		System.out.println(y);
	}

}
