package com.ciitiustech;


interface Filter{
	boolean allowed(int value);
}

/*class Thread{
	
	Runnable r;
	
	public Thread(){}
	
	public Thread(Runnable r){
		this.r = r;
	}
	
	public void start() {
		r.run();
	}
	public void run() {
		
	}
}
*/
/*
class ChildThread extends Thread{
	
	@Override
	public void run() {
		System.out.println("Child thread running.");
	}
}
*/
class Yash implements Filter{
	
	@Override
	public boolean allowed(int val) {
		return val > 0;
	}
}

class ChildThread implements Runnable{
	
	@Override
	public void run() {
		System.out.println("Child thread running.");
	}
}

public class ThreadTest1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//Thread t = new ChildThread();
		//Thread t = new Thread(new ChildThread());
		
		/*
		 * Thread t = new Thread(new Runnable() {
		 * 
		 * @Override public void run() {
		 * System.out.println("Anonymous class method run."); } });
		 */
		Thread t = new Thread(() -> {
			System.out.println("Lambda expression method run.");
		});
		t.start();
	}

}




