package com.ciitiustech;

public class ThreadTest2 {
	
	static String client;
	
	private static void handleJob(int job) {
		System.out.printf("Thread<%d> has accepted job with id %d for client %s%n", Thread.currentThread().hashCode(), job, client);
		Worker.doWork(10 + job);
		System.out.printf("Thread<%d> has finished job with id %d for client %s%n", Thread.currentThread().hashCode(), job, client);
	}

	public static void main(String[] args) {
		Thread child = new Thread(() ->  {
			client = "Jack";
			handleJob(5);
		});
		child.start();
		client = "Jill";
		handleJob(7);
	}
}




