package com.ciitiustech;

public class ThreadMonitorTest {

	static class JointAccount{
		
		private int balance;
		
		public int balance() {
			return balance;
		}
		
		public boolean withdraw(int amount) {
			boolean result = false;
			
			if(balance > amount) {
				Worker.doWork(amount / 500);
				balance -= amount;
				result = true;
			}
			
			return result;
		}
		
		public void deposit(int amount) {
			Worker.doWork(amount / 500);
			balance += amount;
		}
	}
	
	public static void main(String[] args) {
		JointAccount acc = new JointAccount();
		acc.deposit(5000);
		System.out.printf("Yash and Nitesh opened Joint Account with initial balance = %d%n", acc.balance());
		Thread child = new Thread(() ->  {
			if(acc.withdraw(3000) == false) {
				System.out.println("Yash's wihtdraw of 3000 failed...");
			}	
		});
		child.start();
		if(acc.withdraw(4000) == false) {
			System.out.println("Nitesh's wihtdraw of 4000 failed...");
		}
		System.out.printf("Final balance of Joint Account = %d%n", acc.balance());
	}
}




