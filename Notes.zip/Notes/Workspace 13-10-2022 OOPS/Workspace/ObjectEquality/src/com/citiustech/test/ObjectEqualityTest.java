package com.citiustech.test;

import com.citiustech.Interval;

public class ObjectEqualityTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Interval a = new Interval(5, 75);
		a.print();
		Interval b = new Interval(9, 80);
		b.print();
		System.out.println(b);
		System.out.println(b.toString());
	}

}
