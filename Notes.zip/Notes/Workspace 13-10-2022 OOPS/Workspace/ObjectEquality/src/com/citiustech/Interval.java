package com.citiustech;

public class Interval {
	private int minutes;
	private int seconds;
	
	
	public Interval(int minutes, int seconds) {
		this.minutes = minutes + seconds / 60;
		this.seconds = seconds % 60;
	}
	
	public int time() {
		return minutes * 60;
	}
	
	public void print() {
		System.out.println(minutes + ":" + seconds);
	}
	
	@Override
	public String toString() {
		return String.format("%dm:%ds", minutes, seconds);
	}
}








