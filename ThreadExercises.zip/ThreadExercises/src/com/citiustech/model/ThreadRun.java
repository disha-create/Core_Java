package com.citiustech.model;



class Thread1 extends Thread{
	public void run(){
		while(true){
			System.out.println("Good Morning!");
			Thread.sleep(20000);
		}
	}
//	public void run(){
//	
//	for(int i=1;i<5;i++){   
//		  // the thread will sleep for the 500 milli seconds   
//		    try{Thread.sleep(500);}catch(InterruptedException e){System.out.println(e);}    
//		    System.out.println(i);    
//		  } 
//	
//	}
	
}

class Thread2 extends Thread{
	public void run(){
		while(true){
			System.out.println("Purva!");
		}
	}
}

public class ThreadRun {
	
	public static void main(String[] args)throws InterruptedException {
		
		Thread1 t1 = new Thread1();
		Thread2 t2 = new Thread2();
		
		t1.start();
		t1.sleep(200);
		t2.start();
		t2.sleep(200);
		
		
	}

}
